"""
Equipo:
Carlos Andrés Hidalgo Martí
Carlos Rogelio Quirarte Vázquez
"""

class Martillo:
	pass

class Hacha:
	pass

class HachaLujo:
	pass

class Mochila:
	# ---------------------------------------------------------------------------------------------
	# * RETO
	# ---------------------------------------------------------------------------------------------
	# Objetivo: Poder guardar herramientas dentro de la mochila, pero una version de la herramienta
	# a la vez. Por ejemplo, no se puede tener un Hacha normal y un Hacha de lujo en la misma mochila.
	#
	# ---------------------------------------------------------------------------------------------
	# * RETO
	# ---------------------------------------------------------------------------------------------
	# Objetivo: Consolidad las expresiones en las condicionales
	#
	# ---------------------------------------------------------------------------------------------
	# * RETO
	# ---------------------------------------------------------------------------------------------
	# La lógica de las condicionales parece algo compleja
	# Objetivo: Crear métodos para el manero de las expresiones en las condicionales
	#
	# ---------------------------------------------------------------------------------------------
	# * RETO
	# ---------------------------------------------------------------------------------------------
	# Existe código que se repite constantemente
	# Objetivo: Evitar duplicidad de código en cada una de las ramas de las condicionales
	#

	crafts = {
		'martillo': ([('ramita', 3), ('roca', 3), ('cuerda', 2)], Martillo),
		'hacha': ([('ramita', 1), ('pedernal', 1)], Hacha),
		'hacha_lujo': ([('ramita', 4), ('pepita oro', 2)], HachaLujo)
	}

	groups = [
		(Hacha, HachaLujo),
		(Martillo)
	]

	def fabricar(self, herramienta) -> bool:
		'''
		Fabricar herramientas a través de los artículos en tu inventario. Regresa True si se pudo
		fabricar la herramienta
		'''

		if herramienta not in self.crafts:
			return False

		requerimiento, resultado = self.crafts[herramienta]

		for item, quantity in requerimiento.items():
			if self.items.count(item) < quantity:
				print("No tienes suficientes materiales")
				return False

		for g in self.groups:
			if resultado in g and any(self.items.count(item) > 0 for item in g):
				print("Ya tienes una herramienta de este tipo")
				return False

		for item, quantity in requerimiento.items():
			for i in range(quantity):
				self.items.remove(item)


		self.recoger(str(resultado()))
		return True

